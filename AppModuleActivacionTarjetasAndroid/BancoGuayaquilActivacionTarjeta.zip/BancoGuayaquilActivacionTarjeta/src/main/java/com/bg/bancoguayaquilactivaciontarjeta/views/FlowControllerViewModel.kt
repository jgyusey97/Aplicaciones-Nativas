package com.bg.bancoguayaquilactivaciontarjeta.views

import androidx.lifecycle.ViewModel
import com.bg.bancoguayaquilactivaciontarjeta.navigation.ActivationStep
import kotlinx.coroutines.flow.MutableStateFlow

class FlowControllerViewModel : ViewModel() {
    val step = MutableStateFlow(ActivationStep.SELECT_CARD)
    fun goTo(next: ActivationStep) {
        step.value = next
    }

    fun resetFlow() {
        step.value = ActivationStep.SELECT_CARD // o el paso inicial deseado
    }
}
